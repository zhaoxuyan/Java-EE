CREATE VIEW v_db_st AS
  (SELECT DISTINCT
     `student`.`student`.`Sno`   AS `Sno`,
     `student`.`student`.`Sname` AS `Sname`,
     `student`.`student`.`Ssex`  AS `Ssex`,
     `student`.`student`.`Sage`  AS `Sage`,
     `student`.`student`.`Sdept` AS `Sdept`
   FROM `student`.`student`
   WHERE (`student`.`student`.`Sno` = (SELECT `student`.`stu_course`.`Sno`
                                       FROM `student`.`stu_course`
                                         JOIN `student`.`course`
                                         JOIN `student`.`student`
                                       WHERE ((`student`.`student`.`Sdept` = 'CS') AND
                                              (`student`.`course`.`Cno` = `student`.`stu_course`.`Cno`)))));
