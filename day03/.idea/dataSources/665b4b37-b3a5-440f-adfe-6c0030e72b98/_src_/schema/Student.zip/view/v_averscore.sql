CREATE VIEW v_averscore AS
  (SELECT
     `student`.`stu_course`.`Sno`        AS `sno`,
     avg(`student`.`stu_course`.`Grade`) AS `aver_score`
   FROM `student`.`stu_course`
   GROUP BY `student`.`stu_course`.`Sno`);
